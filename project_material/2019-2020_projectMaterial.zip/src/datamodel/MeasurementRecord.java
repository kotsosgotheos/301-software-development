package datamodel;


public class MeasurementRecord {
... συμπληρώστε ...	
}
